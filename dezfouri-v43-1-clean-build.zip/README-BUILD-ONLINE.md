# Dezfouri Android v43.1

این پروژه از ریشه Repository ساخته می‌شود. هیچ دستور `cd project/v43work` وجود ندارد.

GitHub Actions به‌صورت خودکار APK Debug را می‌سازد.
